import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Calendar, Plus, Clock, User, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { ScheduleEvent } from '@/types';

const mockEvents: ScheduleEvent[] = [
  { id: '1', title: 'Strength Training', traineeId: '1', traineeName: 'Sarah Johnson', date: new Date(), startTime: '09:00', endTime: '10:00', type: 'training' },
  { id: '2', title: 'HIIT Session', traineeId: '2', traineeName: 'Mike Chen', date: new Date(), startTime: '11:00', endTime: '12:00', type: 'training' },
  { id: '3', title: 'Initial Assessment', traineeId: '3', traineeName: 'Emma Davis', date: new Date(), startTime: '14:00', endTime: '15:00', type: 'assessment' },
  { id: '4', title: 'Progress Review', traineeId: '4', traineeName: 'Tom Wilson', date: new Date(), startTime: '16:00', endTime: '17:00', type: 'consultation' },
];

const Schedule: React.FC = () => {
  const [events, setEvents] = useState<ScheduleEvent[]>(mockEvents);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [newEvent, setNewEvent] = useState<{
    title: string;
    traineeName: string;
    startTime: string;
    endTime: string;
    type: 'training' | 'consultation' | 'assessment';
    notes: string;
  }>({
    title: '',
    traineeName: '',
    startTime: '',
    endTime: '',
    type: 'training' as const,
    notes: '',
  });

  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const timeSlots = Array.from({ length: 12 }, (_, i) => `${(i + 8).toString().padStart(2, '0')}:00`);

  const getWeekDates = () => {
    const start = new Date(selectedDate);
    start.setDate(start.getDate() - start.getDay() + 1);
    return Array.from({ length: 7 }, (_, i) => {
      const date = new Date(start);
      date.setDate(start.getDate() + i);
      return date;
    });
  };

  const weekDates = getWeekDates();

  const handleAddEvent = () => {
    if (!newEvent.title || !newEvent.traineeName || !newEvent.startTime || !newEvent.endTime) {
      toast.error('Please fill in all required fields');
      return;
    }

    const event: ScheduleEvent = {
      id: Date.now().toString(),
      ...newEvent,
      traineeId: Date.now().toString(),
      date: selectedDate,
    };

    setEvents([...events, event]);
    setIsDialogOpen(false);
    setNewEvent({ title: '', traineeName: '', startTime: '', endTime: '', type: 'training', notes: '' });
    toast.success('Session scheduled successfully!');
  };

  const handleDeleteEvent = (id: string) => {
    setEvents(events.filter(e => e.id !== id));
    toast.success('Session deleted');
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'training': return 'bg-primary';
      case 'consultation': return 'bg-accent';
      case 'assessment': return 'bg-purple-500';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-5xl mb-2">SCHEDULE</h1>
          <p className="text-muted-foreground">Manage your training sessions</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="gradient" size="lg">
              <Plus className="w-5 h-5" />
              Add Session
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="font-display text-2xl">NEW SESSION</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Session Title</Label>
                <Input
                  placeholder="e.g., Strength Training"
                  value={newEvent.title}
                  onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Client Name</Label>
                <Input
                  placeholder="Enter client name"
                  value={newEvent.traineeName}
                  onChange={(e) => setNewEvent({ ...newEvent, traineeName: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Start Time</Label>
                  <Input
                    type="time"
                    value={newEvent.startTime}
                    onChange={(e) => setNewEvent({ ...newEvent, startTime: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>End Time</Label>
                  <Input
                    type="time"
                    value={newEvent.endTime}
                    onChange={(e) => setNewEvent({ ...newEvent, endTime: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Session Type</Label>
                <Select
                  value={newEvent.type}
                  onValueChange={(value: 'training' | 'consultation' | 'assessment') => 
                    setNewEvent({ ...newEvent, type: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="consultation">Consultation</SelectItem>
                    <SelectItem value="assessment">Assessment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Notes (Optional)</Label>
                <Textarea
                  placeholder="Add any notes..."
                  value={newEvent.notes}
                  onChange={(e) => setNewEvent({ ...newEvent, notes: e.target.value })}
                />
              </div>
              <Button onClick={handleAddEvent} variant="gradient" className="w-full">
                Schedule Session
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Calendar Header */}
      <div className="glass-card p-4">
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" onClick={() => {
            const newDate = new Date(selectedDate);
            newDate.setDate(newDate.getDate() - 7);
            setSelectedDate(newDate);
          }}>
            Previous Week
          </Button>
          <h2 className="font-display text-xl">
            {selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </h2>
          <Button variant="ghost" onClick={() => {
            const newDate = new Date(selectedDate);
            newDate.setDate(newDate.getDate() + 7);
            setSelectedDate(newDate);
          }}>
            Next Week
          </Button>
        </div>

        {/* Week Grid */}
        <div className="grid grid-cols-8 gap-2">
          {/* Time Column */}
          <div className="space-y-2">
            <div className="h-12" />
            {timeSlots.map((time) => (
              <div key={time} className="h-16 flex items-center text-sm text-muted-foreground">
                {time}
              </div>
            ))}
          </div>

          {/* Day Columns */}
          {weekDates.map((date, dayIndex) => (
            <div key={dayIndex} className="space-y-2">
              <div className="h-12 text-center">
                <p className="text-sm text-muted-foreground">{weekDays[dayIndex]}</p>
                <p className={`font-medium ${date.toDateString() === new Date().toDateString() ? 'text-primary' : ''}`}>
                  {date.getDate()}
                </p>
              </div>
              {timeSlots.map((time) => {
                const event = events.find(e => 
                  e.date.toDateString() === date.toDateString() && 
                  e.startTime === time
                );
                return (
                  <div key={time} className="h-16 border border-border/30 rounded-lg relative">
                    {event && (
                      <div className={`absolute inset-1 ${getTypeColor(event.type)} rounded-md p-2 text-xs overflow-hidden group`}>
                        <p className="font-medium truncate text-primary-foreground">{event.title}</p>
                        <p className="truncate text-primary-foreground/80">{event.traineeName}</p>
                        <button
                          onClick={() => handleDeleteEvent(event.id)}
                          className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-3 h-3 text-primary-foreground" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Today's Sessions List */}
      <div className="glass-card p-6">
        <h2 className="font-display text-2xl mb-4">TODAY'S SESSIONS</h2>
        <div className="space-y-3">
          {events
            .filter(e => e.date.toDateString() === new Date().toDateString())
            .sort((a, b) => a.startTime.localeCompare(b.startTime))
            .map((event) => (
              <div key={event.id} className="flex items-center gap-4 p-4 bg-secondary rounded-lg">
                <div className={`w-2 h-12 rounded-full ${getTypeColor(event.type)}`} />
                <div className="flex-1">
                  <p className="font-medium">{event.title}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {event.traineeName}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {event.startTime} - {event.endTime}
                    </span>
                  </div>
                </div>
                <Button variant="outline" size="sm">View</Button>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default Schedule;
