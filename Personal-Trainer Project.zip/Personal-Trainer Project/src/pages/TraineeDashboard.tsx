import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Calendar, Dumbbell, Clock, TrendingUp, MessageSquare, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Link } from 'react-router-dom';

const TraineeDashboard: React.FC = () => {
  const { user } = useAuth();

  const todayWorkout = {
    name: "Upper Body Strength",
    exercises: [
      { name: "Bench Press", sets: 4, reps: "8-10", completed: true },
      { name: "Dumbbell Rows", sets: 4, reps: "10-12", completed: true },
      { name: "Shoulder Press", sets: 3, reps: "10-12", completed: false },
      { name: "Bicep Curls", sets: 3, reps: "12-15", completed: false },
      { name: "Tricep Dips", sets: 3, reps: "12-15", completed: false },
    ],
    duration: "45 min",
    progress: 40,
  };

  const upcomingSessions = [
    { day: "Today", time: "4:00 PM", type: "Upper Body Strength" },
    { day: "Tomorrow", time: "10:00 AM", type: "HIIT Cardio" },
    { day: "Thursday", time: "4:00 PM", type: "Lower Body Power" },
  ];

  const weeklyProgress = [
    { day: "Mon", completed: true },
    { day: "Tue", completed: true },
    { day: "Wed", completed: false },
    { day: "Thu", completed: false },
    { day: "Fri", completed: false },
    { day: "Sat", completed: false },
    { day: "Sun", completed: false },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="animate-fade-in">
        <h1 className="font-display text-5xl mb-2">WELCOME BACK, {user?.name?.toUpperCase()}</h1>
        <p className="text-muted-foreground text-lg">Here's your training overview for today</p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="glass-card p-6 animate-slide-up">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span className="text-muted-foreground">This Week</span>
          </div>
          <p className="font-display text-3xl">4 Sessions</p>
        </div>
        <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '100ms' }}>
          <div className="flex items-center gap-3 mb-2">
            <Dumbbell className="w-5 h-5 text-accent" />
            <span className="text-muted-foreground">Exercises Done</span>
          </div>
          <p className="font-display text-3xl">48</p>
        </div>
        <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '200ms' }}>
          <div className="flex items-center gap-3 mb-2">
            <Clock className="w-5 h-5 text-primary" />
            <span className="text-muted-foreground">Training Time</span>
          </div>
          <p className="font-display text-3xl">6.5h</p>
        </div>
        <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '300ms' }}>
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-5 h-5 text-accent" />
            <span className="text-muted-foreground">Goal Progress</span>
          </div>
          <p className="font-display text-3xl">78%</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Workout */}
        <div className="lg:col-span-2 glass-card p-6 animate-slide-up" style={{ animationDelay: '400ms' }}>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="font-display text-2xl">TODAY'S WORKOUT</h2>
              <p className="text-muted-foreground">{todayWorkout.name} • {todayWorkout.duration}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Progress</p>
              <p className="font-display text-2xl text-primary">{todayWorkout.progress}%</p>
            </div>
          </div>

          <Progress value={todayWorkout.progress} className="mb-6 h-2" />

          <div className="space-y-3">
            {todayWorkout.exercises.map((exercise, index) => (
              <div
                key={exercise.name}
                className={`flex items-center justify-between p-4 rounded-lg transition-all ${
                  exercise.completed ? 'bg-primary/10' : 'bg-secondary'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    exercise.completed ? 'bg-primary' : 'bg-muted'
                  }`}>
                    {exercise.completed ? (
                      <CheckCircle className="w-5 h-5 text-primary-foreground" />
                    ) : (
                      <span className="text-sm font-medium">{index + 1}</span>
                    )}
                  </div>
                  <div>
                    <p className={`font-medium ${exercise.completed ? 'text-primary' : ''}`}>
                      {exercise.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {exercise.sets} sets × {exercise.reps} reps
                    </p>
                  </div>
                </div>
                {!exercise.completed && (
                  <Button variant="ghost" size="sm">Start</Button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Weekly Progress */}
          <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '500ms' }}>
            <h3 className="font-display text-xl mb-4">WEEKLY PROGRESS</h3>
            <div className="flex justify-between">
              {weeklyProgress.map((day) => (
                <div key={day.day} className="text-center">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-2 ${
                    day.completed ? 'bg-primary' : 'bg-secondary'
                  }`}>
                    {day.completed && <CheckCircle className="w-5 h-5 text-primary-foreground" />}
                  </div>
                  <p className="text-xs text-muted-foreground">{day.day}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Sessions */}
          <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '600ms' }}>
            <h3 className="font-display text-xl mb-4">UPCOMING SESSIONS</h3>
            <div className="space-y-3">
              {upcomingSessions.map((session, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-secondary rounded-lg">
                  <div className="w-12 text-center">
                    <p className="text-xs text-muted-foreground">{session.day}</p>
                    <p className="font-medium text-sm">{session.time}</p>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{session.type}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Message Trainer */}
          <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '700ms' }}>
            <h3 className="font-display text-xl mb-4">YOUR TRAINER</h3>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                AT
              </div>
              <div>
                <p className="font-medium">Alex Thompson</p>
                <p className="text-sm text-primary">Online</p>
              </div>
            </div>
            <Link to="/messages">
              <Button variant="outline" className="w-full">
                <MessageSquare className="w-4 h-4 mr-2" />
                Send Message
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TraineeDashboard;
