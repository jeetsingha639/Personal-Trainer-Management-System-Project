import React from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Calendar, Users, Dumbbell, MessageSquare, TrendingUp, Clock } from 'lucide-react';

const StatCard: React.FC<{
  icon: React.ElementType;
  label: string;
  value: string | number;
  trend?: string;
  color: string;
}> = ({ icon: Icon, label, value, trend, color }) => (
  <div className="glass-card p-6 animate-slide-up">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-muted-foreground text-sm mb-1">{label}</p>
        <p className="font-display text-4xl">{value}</p>
        {trend && (
          <p className="text-primary text-sm flex items-center gap-1 mt-2">
            <TrendingUp className="w-4 h-4" />
            {trend}
          </p>
        )}
      </div>
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon className="w-6 h-6 text-primary-foreground" />
      </div>
    </div>
  </div>
);

const UpcomingSession: React.FC<{
  name: string;
  time: string;
  type: string;
}> = ({ name, time, type }) => (
  <div className="flex items-center gap-4 p-4 bg-secondary rounded-lg hover:bg-secondary/80 transition-colors">
    <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">
      {name.charAt(0)}
    </div>
    <div className="flex-1">
      <p className="font-medium">{name}</p>
      <p className="text-sm text-muted-foreground">{type}</p>
    </div>
    <div className="text-right">
      <p className="text-sm font-medium">{time}</p>
    </div>
  </div>
);

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const isTrainer = user?.role === 'trainer';

  const trainerStats = [
    { icon: Users, label: 'Active Clients', value: 24, trend: '+3 this week', color: 'gradient-primary' },
    { icon: Calendar, label: 'Sessions Today', value: 8, color: 'bg-accent' },
    { icon: Dumbbell, label: 'Exercises', value: 156, color: 'bg-secondary' },
    { icon: MessageSquare, label: 'Unread Messages', value: 5, color: 'bg-destructive' },
  ];

  const traineeStats = [
    { icon: Calendar, label: 'Sessions This Week', value: 4, color: 'gradient-primary' },
    { icon: Dumbbell, label: 'Exercises Completed', value: 48, trend: '+12 this week', color: 'bg-accent' },
    { icon: Clock, label: 'Training Hours', value: '6.5h', color: 'bg-secondary' },
    { icon: TrendingUp, label: 'Progress', value: '78%', color: 'bg-primary' },
  ];

  const stats = isTrainer ? trainerStats : traineeStats;

  const upcomingSessions = [
    { name: 'Sarah Johnson', time: '9:00 AM', type: 'Strength Training' },
    { name: 'Mike Chen', time: '11:00 AM', type: 'HIIT Session' },
    { name: 'Emma Davis', time: '2:00 PM', type: 'Flexibility' },
    { name: 'Tom Wilson', time: '4:00 PM', type: 'Personal Training' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="animate-fade-in">
        <h1 className="font-display text-5xl mb-2">
          {isTrainer ? 'TRAINER DASHBOARD' : 'MY DASHBOARD'}
        </h1>
        <p className="text-muted-foreground text-lg">
          Welcome back, {user?.name}! Here's your overview.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={stat.label} style={{ animationDelay: `${index * 100}ms` }}>
            <StatCard {...stat} />
          </div>
        ))}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Sessions */}
        <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '400ms' }}>
          <h2 className="font-display text-2xl mb-4">UPCOMING SESSIONS</h2>
          <div className="space-y-3">
            {upcomingSessions.map((session) => (
              <UpcomingSession key={session.name + session.time} {...session} />
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="glass-card p-6 animate-slide-up" style={{ animationDelay: '500ms' }}>
          <h2 className="font-display text-2xl mb-4">QUICK ACTIONS</h2>
          <div className="grid grid-cols-2 gap-4">
            <button className="p-6 bg-secondary rounded-xl hover:bg-secondary/80 transition-all hover:scale-105 text-left">
              <Calendar className="w-8 h-8 text-primary mb-3" />
              <p className="font-medium">Schedule Session</p>
              <p className="text-sm text-muted-foreground">Book a new appointment</p>
            </button>
            <button className="p-6 bg-secondary rounded-xl hover:bg-secondary/80 transition-all hover:scale-105 text-left">
              <MessageSquare className="w-8 h-8 text-accent mb-3" />
              <p className="font-medium">Send Message</p>
              <p className="text-sm text-muted-foreground">Contact your {isTrainer ? 'clients' : 'trainer'}</p>
            </button>
            <button className="p-6 bg-secondary rounded-xl hover:bg-secondary/80 transition-all hover:scale-105 text-left">
              <Dumbbell className="w-8 h-8 text-primary mb-3" />
              <p className="font-medium">{isTrainer ? 'Add Exercise' : 'View Workout'}</p>
              <p className="text-sm text-muted-foreground">{isTrainer ? 'Create new exercise' : 'See today\'s plan'}</p>
            </button>
            <button className="p-6 bg-secondary rounded-xl hover:bg-secondary/80 transition-all hover:scale-105 text-left">
              <TrendingUp className="w-8 h-8 text-accent mb-3" />
              <p className="font-medium">View Progress</p>
              <p className="text-sm text-muted-foreground">Track performance</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
