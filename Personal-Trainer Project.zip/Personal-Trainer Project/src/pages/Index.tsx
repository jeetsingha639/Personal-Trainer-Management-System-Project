import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Dumbbell, Calendar, Users, MessageSquare, ArrowRight, CheckCircle } from 'lucide-react';

const Index: React.FC = () => {
  const features = [
    { icon: Calendar, title: 'Smart Scheduling', description: 'Effortlessly manage your sessions with an intuitive calendar' },
    { icon: Users, title: 'Client Management', description: 'Track progress and communicate with all your trainees' },
    { icon: Dumbbell, title: 'Exercise Library', description: 'Build custom workouts from your personal exercise database' },
    { icon: MessageSquare, title: 'Real-time Chat', description: 'Stay connected with instant messaging capabilities' },
  ];

  const benefits = [
    'Manage unlimited clients',
    'Create custom workout plans',
    'Track progress metrics',
    'Send instant messages',
    'Schedule with ease',
    'Mobile-friendly design',
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-10" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(34,197,94,0.1),transparent_50%)]" />
        
        <nav className="relative z-10 container mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 gradient-primary rounded-lg">
              <Dumbbell className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="font-display text-2xl">FITPRO</span>
          </div>
          <Link to="/auth">
            <Button variant="outline">Sign In</Button>
          </Link>
        </nav>

        <div className="relative z-10 container mx-auto px-6 py-24 lg:py-32">
          <div className="max-w-3xl">
            <h1 className="font-display text-6xl lg:text-8xl mb-6 animate-fade-in">
              ELEVATE YOUR
              <br />
              <span className="text-gradient">TRAINING BUSINESS</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 animate-slide-up" style={{ animationDelay: '200ms' }}>
              The all-in-one platform for personal trainers to manage clients, 
              schedule sessions, and track progress with powerful, intuitive tools.
            </p>
            <div className="flex flex-wrap gap-4 animate-slide-up" style={{ animationDelay: '400ms' }}>
              <Link to="/auth">
                <Button variant="gradient" size="xl">
                  Get Started Free
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Button variant="outline" size="xl">
                Watch Demo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 relative">
        <div className="container mx-auto px-6">
          <h2 className="font-display text-4xl lg:text-5xl text-center mb-4">
            EVERYTHING YOU NEED
          </h2>
          <p className="text-muted-foreground text-center mb-16 max-w-2xl mx-auto">
            Powerful features designed specifically for fitness professionals
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="glass-card p-8 hover:border-primary/50 transition-all duration-300 animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="p-4 gradient-primary rounded-xl inline-block mb-6">
                  <feature.icon className="w-8 h-8 text-primary-foreground" />
                </div>
                <h3 className="font-display text-2xl mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-24 bg-secondary/30">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="font-display text-4xl lg:text-5xl mb-6">
                WHY TRAINERS
                <br />
                <span className="text-gradient">CHOOSE FITPRO</span>
              </h2>
              <p className="text-muted-foreground text-lg mb-8">
                Join thousands of fitness professionals who have transformed their 
                training business with our comprehensive platform.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {benefits.map((benefit) => (
                  <div key={benefit} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-primary shrink-0" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <div className="glass-card p-8">
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-4 bg-secondary rounded-lg">
                    <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                      SJ
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Sarah Johnson</p>
                      <p className="text-sm text-muted-foreground">Strength Training • 9:00 AM</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-secondary rounded-lg">
                    <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center text-accent-foreground font-bold">
                      MC
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Mike Chen</p>
                      <p className="text-sm text-muted-foreground">HIIT Session • 11:00 AM</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 p-4 bg-secondary rounded-lg">
                    <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                      ED
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">Emma Davis</p>
                      <p className="text-sm text-muted-foreground">Flexibility • 2:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 w-32 h-32 gradient-primary rounded-full opacity-20 blur-3xl" />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container mx-auto px-6 text-center">
          <h2 className="font-display text-4xl lg:text-6xl mb-6">
            READY TO TRANSFORM
            <br />
            YOUR TRAINING BUSINESS?
          </h2>
          <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto">
            Start managing your clients more efficiently today. Free to get started.
          </p>
          <Link to="/auth">
            <Button variant="gradient" size="xl">
              Start Free Trial
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-primary" />
            <span className="font-display">FITPRO</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © 2024 FitPro. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
