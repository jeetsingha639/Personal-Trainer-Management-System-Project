import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, Search, MoreVertical } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Message } from '@/types';

interface Conversation {
  id: string;
  name: string;
  lastMessage: string;
  timestamp: Date;
  unread: number;
  avatar?: string;
}

const mockConversations: Conversation[] = [
  { id: '1', name: 'Sarah Johnson', lastMessage: 'Thanks for the workout plan!', timestamp: new Date(), unread: 2 },
  { id: '2', name: 'Mike Chen', lastMessage: 'Can we reschedule tomorrow?', timestamp: new Date(Date.now() - 3600000), unread: 0 },
  { id: '3', name: 'Emma Davis', lastMessage: 'Got it, see you at 2pm', timestamp: new Date(Date.now() - 7200000), unread: 1 },
  { id: '4', name: 'Tom Wilson', lastMessage: 'How many sets should I do?', timestamp: new Date(Date.now() - 86400000), unread: 0 },
  { id: '5', name: 'Lisa Brown', lastMessage: 'Perfect, thank you!', timestamp: new Date(Date.now() - 172800000), unread: 0 },
];

const mockMessages: Record<string, Message[]> = {
  '1': [
    { id: '1', senderId: '1', senderName: 'Sarah Johnson', receiverId: 'trainer', content: 'Hi! I wanted to ask about my nutrition plan', timestamp: new Date(Date.now() - 3600000), read: true },
    { id: '2', senderId: 'trainer', senderName: 'You', receiverId: '1', content: 'Of course! What questions do you have?', timestamp: new Date(Date.now() - 3500000), read: true },
    { id: '3', senderId: '1', senderName: 'Sarah Johnson', receiverId: 'trainer', content: 'Should I be eating more protein on rest days?', timestamp: new Date(Date.now() - 3400000), read: true },
    { id: '4', senderId: 'trainer', senderName: 'You', receiverId: '1', content: 'Great question! Yes, protein intake should remain consistent even on rest days as muscle recovery happens during rest.', timestamp: new Date(Date.now() - 3300000), read: true },
    { id: '5', senderId: '1', senderName: 'Sarah Johnson', receiverId: 'trainer', content: 'Thanks for the workout plan!', timestamp: new Date(Date.now() - 60000), read: false },
    { id: '6', senderId: '1', senderName: 'Sarah Johnson', receiverId: 'trainer', content: 'Really excited to start tomorrow!', timestamp: new Date(), read: false },
  ],
  '2': [
    { id: '1', senderId: '2', senderName: 'Mike Chen', receiverId: 'trainer', content: 'Hey coach, can we reschedule tomorrow?', timestamp: new Date(Date.now() - 3600000), read: true },
  ],
};

const Messages: React.FC = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>(mockConversations);
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(conversations[0]);
  const [messages, setMessages] = useState<Message[]>(mockMessages['1'] || []);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSelectConversation = (conversation: Conversation) => {
    setSelectedConversation(conversation);
    setMessages(mockMessages[conversation.id] || []);
    // Mark as read
    setConversations(conversations.map(c => 
      c.id === conversation.id ? { ...c, unread: 0 } : c
    ));
  };

  const handleSendMessage = () => {
    if (!newMessage.trim() || !selectedConversation) return;

    const message: Message = {
      id: Date.now().toString(),
      senderId: user?.id || 'trainer',
      senderName: user?.name || 'You',
      receiverId: selectedConversation.id,
      content: newMessage,
      timestamp: new Date(),
      read: false,
    };

    setMessages([...messages, message]);
    setNewMessage('');

    // Update conversation preview
    setConversations(conversations.map(c =>
      c.id === selectedConversation.id
        ? { ...c, lastMessage: newMessage, timestamp: new Date() }
        : c
    ));
  };

  const filteredConversations = conversations.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    } else if (days === 1) {
      return 'Yesterday';
    } else if (days < 7) {
      return date.toLocaleDateString([], { weekday: 'short' });
    } else {
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="h-[calc(100vh-8rem)]">
      <h1 className="font-display text-5xl mb-6">MESSAGES</h1>
      
      <div className="glass-card h-[calc(100%-4rem)] flex overflow-hidden">
        {/* Conversations List */}
        <div className="w-80 border-r border-border flex flex-col">
          <div className="p-4 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-9"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filteredConversations.map((conversation) => (
              <button
                key={conversation.id}
                onClick={() => handleSelectConversation(conversation)}
                className={cn(
                  "w-full p-4 flex items-center gap-3 hover:bg-secondary/50 transition-colors text-left",
                  selectedConversation?.id === conversation.id && "bg-secondary"
                )}
              >
                <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold shrink-0">
                  {conversation.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="font-medium truncate">{conversation.name}</p>
                    <span className="text-xs text-muted-foreground">
                      {formatTime(conversation.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground truncate">{conversation.lastMessage}</p>
                </div>
                {conversation.unread > 0 && (
                  <div className="w-5 h-5 rounded-full bg-primary flex items-center justify-center text-xs text-primary-foreground font-bold">
                    {conversation.unread}
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Area */}
        {selectedConversation ? (
          <div className="flex-1 flex flex-col">
            {/* Chat Header */}
            <div className="p-4 border-b border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                  {selectedConversation.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium">{selectedConversation.name}</p>
                  <p className="text-xs text-primary">Online</p>
                </div>
              </div>
              <button className="p-2 hover:bg-secondary rounded-lg transition-colors">
                <MoreVertical className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => {
                const isOwn = message.senderId === user?.id || message.senderId === 'trainer';
                return (
                  <div
                    key={message.id}
                    className={cn(
                      "flex",
                      isOwn ? "justify-end" : "justify-start"
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[70%] rounded-2xl px-4 py-2",
                        isOwn
                          ? "bg-primary text-primary-foreground rounded-br-md"
                          : "bg-secondary rounded-bl-md"
                      )}
                    >
                      <p>{message.content}</p>
                      <p className={cn(
                        "text-xs mt-1",
                        isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
                      )}>
                        {formatTime(message.timestamp)}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-border">
              <div className="flex gap-2">
                <Input
                  placeholder="Type a message..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                  className="flex-1"
                />
                <Button onClick={handleSendMessage} variant="gradient">
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-muted-foreground">Select a conversation to start messaging</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Messages;
