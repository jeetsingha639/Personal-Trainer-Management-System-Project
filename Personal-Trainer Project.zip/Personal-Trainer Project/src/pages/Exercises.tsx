import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Plus, Search, Filter, Dumbbell, Clock, Flame, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { Exercise } from '@/types';

const mockExercises: Exercise[] = [
  { id: '1', name: 'Barbell Squat', category: 'Strength', muscleGroup: 'Legs', description: 'Compound lower body exercise', instructions: ['Stand with feet shoulder-width apart', 'Lower your body by bending knees', 'Keep back straight', 'Push through heels to return'], sets: 4, reps: '8-12', difficulty: 'intermediate' },
  { id: '2', name: 'Deadlift', category: 'Strength', muscleGroup: 'Back', description: 'Full body compound movement', instructions: ['Stand with feet hip-width apart', 'Grip bar outside knees', 'Keep back neutral', 'Drive through heels'], sets: 4, reps: '6-8', difficulty: 'advanced' },
  { id: '3', name: 'Push-ups', category: 'Bodyweight', muscleGroup: 'Chest', description: 'Classic upper body exercise', instructions: ['Start in plank position', 'Lower chest to ground', 'Push back up'], sets: 3, reps: '15-20', difficulty: 'beginner' },
  { id: '4', name: 'Pull-ups', category: 'Bodyweight', muscleGroup: 'Back', description: 'Upper body pulling movement', instructions: ['Hang from bar with arms extended', 'Pull yourself up until chin over bar', 'Lower with control'], sets: 3, reps: '8-12', difficulty: 'intermediate' },
  { id: '5', name: 'Plank', category: 'Core', muscleGroup: 'Core', description: 'Isometric core exercise', instructions: ['Start in forearm position', 'Keep body straight', 'Hold position'], duration: '60 seconds', difficulty: 'beginner' },
  { id: '6', name: 'Burpees', category: 'HIIT', muscleGroup: 'Full Body', description: 'High intensity cardio movement', instructions: ['Start standing', 'Drop to push-up', 'Jump back up', 'Reach arms overhead'], sets: 3, reps: '10-15', difficulty: 'intermediate' },
];

const categories = ['All', 'Strength', 'Bodyweight', 'Core', 'HIIT', 'Cardio', 'Flexibility'];
const muscleGroups = ['All', 'Legs', 'Back', 'Chest', 'Shoulders', 'Arms', 'Core', 'Full Body'];
const difficulties = ['beginner', 'intermediate', 'advanced'] as const;

const Exercises: React.FC = () => {
  const [exercises, setExercises] = useState<Exercise[]>(mockExercises);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedMuscle, setSelectedMuscle] = useState('All');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingExercise, setEditingExercise] = useState<Exercise | null>(null);
  const [newExercise, setNewExercise] = useState<{
    name: string;
    category: string;
    muscleGroup: string;
    description: string;
    instructions: string[];
    sets: number;
    reps: string;
    duration: string;
    difficulty: 'beginner' | 'intermediate' | 'advanced';
  }>({
    name: '',
    category: 'Strength',
    muscleGroup: 'Chest',
    description: '',
    instructions: [''],
    sets: 3,
    reps: '10-12',
    duration: '',
    difficulty: 'intermediate',
  });

  const filteredExercises = exercises.filter(e => {
    const matchesSearch = e.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || e.category === selectedCategory;
    const matchesMuscle = selectedMuscle === 'All' || e.muscleGroup === selectedMuscle;
    return matchesSearch && matchesCategory && matchesMuscle;
  });

  const handleAddExercise = () => {
    if (!newExercise.name || !newExercise.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingExercise) {
      setExercises(exercises.map(e => e.id === editingExercise.id ? { ...newExercise, id: e.id } : e));
      toast.success('Exercise updated!');
    } else {
      const exercise: Exercise = {
        id: Date.now().toString(),
        ...newExercise,
        instructions: newExercise.instructions.filter(i => i.trim()),
      };
      setExercises([...exercises, exercise]);
      toast.success('Exercise added!');
    }

    setIsDialogOpen(false);
    setEditingExercise(null);
    setNewExercise({
      name: '', category: 'Strength', muscleGroup: 'Chest', description: '',
      instructions: [''], sets: 3, reps: '10-12', duration: '', difficulty: 'intermediate',
    });
  };

  const handleEdit = (exercise: Exercise) => {
    setEditingExercise(exercise);
    setNewExercise({
      name: exercise.name,
      category: exercise.category,
      muscleGroup: exercise.muscleGroup,
      description: exercise.description,
      instructions: exercise.instructions.length ? exercise.instructions : [''],
      sets: exercise.sets || 3,
      reps: exercise.reps || '10-12',
      duration: exercise.duration || '',
      difficulty: exercise.difficulty,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setExercises(exercises.filter(e => e.id !== id));
    toast.success('Exercise deleted');
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'bg-primary/20 text-primary';
      case 'intermediate': return 'bg-accent/20 text-accent';
      case 'advanced': return 'bg-destructive/20 text-destructive';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-5xl mb-2">EXERCISES</h1>
          <p className="text-muted-foreground">Build your exercise library</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={(open) => {
          setIsDialogOpen(open);
          if (!open) {
            setEditingExercise(null);
            setNewExercise({
              name: '', category: 'Strength', muscleGroup: 'Chest', description: '',
              instructions: [''], sets: 3, reps: '10-12', duration: '', difficulty: 'intermediate',
            });
          }
        }}>
          <DialogTrigger asChild>
            <Button variant="gradient" size="lg">
              <Plus className="w-5 h-5" />
              Add Exercise
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-display text-2xl">
                {editingExercise ? 'EDIT EXERCISE' : 'NEW EXERCISE'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Exercise Name</Label>
                <Input
                  placeholder="e.g., Barbell Squat"
                  value={newExercise.name}
                  onChange={(e) => setNewExercise({ ...newExercise, name: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category</Label>
                  <Select
                    value={newExercise.category}
                    onValueChange={(value) => setNewExercise({ ...newExercise, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.filter(c => c !== 'All').map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Muscle Group</Label>
                  <Select
                    value={newExercise.muscleGroup}
                    onValueChange={(value) => setNewExercise({ ...newExercise, muscleGroup: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {muscleGroups.filter(m => m !== 'All').map((muscle) => (
                        <SelectItem key={muscle} value={muscle}>{muscle}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Difficulty</Label>
                <Select
                  value={newExercise.difficulty}
                  onValueChange={(value: typeof difficulties[number]) => setNewExercise({ ...newExercise, difficulty: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {difficulties.map((diff) => (
                      <SelectItem key={diff} value={diff} className="capitalize">{diff}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Description</Label>
                <Textarea
                  placeholder="Brief description of the exercise"
                  value={newExercise.description}
                  onChange={(e) => setNewExercise({ ...newExercise, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Sets</Label>
                  <Input
                    type="number"
                    value={newExercise.sets}
                    onChange={(e) => setNewExercise({ ...newExercise, sets: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Reps</Label>
                  <Input
                    placeholder="e.g., 10-12"
                    value={newExercise.reps}
                    onChange={(e) => setNewExercise({ ...newExercise, reps: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Duration</Label>
                  <Input
                    placeholder="e.g., 60 sec"
                    value={newExercise.duration}
                    onChange={(e) => setNewExercise({ ...newExercise, duration: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Instructions</Label>
                {newExercise.instructions.map((instruction, index) => (
                  <div key={index} className="flex gap-2">
                    <span className="text-muted-foreground mt-2">{index + 1}.</span>
                    <Input
                      placeholder={`Step ${index + 1}`}
                      value={instruction}
                      onChange={(e) => {
                        const updated = [...newExercise.instructions];
                        updated[index] = e.target.value;
                        setNewExercise({ ...newExercise, instructions: updated });
                      }}
                    />
                  </div>
                ))}
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setNewExercise({ ...newExercise, instructions: [...newExercise.instructions, ''] })}
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Add Step
                </Button>
              </div>

              <Button onClick={handleAddExercise} variant="gradient" className="w-full">
                {editingExercise ? 'Update Exercise' : 'Add Exercise'}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search exercises..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-11"
          />
        </div>
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-[150px]">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={selectedMuscle} onValueChange={setSelectedMuscle}>
          <SelectTrigger className="w-[150px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {muscleGroups.map((muscle) => (
              <SelectItem key={muscle} value={muscle}>{muscle}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Exercises Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExercises.map((exercise, index) => (
          <div
            key={exercise.id}
            className="glass-card p-6 animate-slide-up hover:border-primary/50 transition-all group"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-lg">{exercise.name}</h3>
                <p className="text-sm text-muted-foreground">{exercise.muscleGroup}</p>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => handleEdit(exercise)}
                  className="p-2 hover:bg-secondary rounded-lg transition-colors"
                >
                  <Edit className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleDelete(exercise.id)}
                  className="p-2 hover:bg-destructive/10 text-destructive rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            <p className="text-sm text-muted-foreground mb-4">{exercise.description}</p>

            <div className="flex flex-wrap gap-2 mb-4">
              <Badge variant="secondary">{exercise.category}</Badge>
              <Badge className={getDifficultyColor(exercise.difficulty)}>{exercise.difficulty}</Badge>
            </div>

            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              {exercise.sets && (
                <span className="flex items-center gap-1">
                  <Dumbbell className="w-4 h-4" />
                  {exercise.sets} sets
                </span>
              )}
              {exercise.reps && (
                <span className="flex items-center gap-1">
                  <Flame className="w-4 h-4" />
                  {exercise.reps} reps
                </span>
              )}
              {exercise.duration && (
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {exercise.duration}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredExercises.length === 0 && (
        <div className="text-center py-12">
          <Dumbbell className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">No exercises found</p>
          <Button variant="ghost" className="mt-4" onClick={() => {
            setSearchQuery('');
            setSelectedCategory('All');
            setSelectedMuscle('All');
          }}>
            Clear filters
          </Button>
        </div>
      )}
    </div>
  );
};

export default Exercises;
