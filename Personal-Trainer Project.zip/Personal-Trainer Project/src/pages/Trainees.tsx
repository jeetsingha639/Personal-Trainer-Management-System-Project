import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Plus, Search, MessageSquare, Calendar, TrendingUp, MoreVertical } from 'lucide-react';
import { toast } from 'sonner';
import { Trainee } from '@/types';

const mockTrainees: Trainee[] = [
  { id: '1', name: 'Sarah Johnson', email: 'sarah@email.com', goals: 'Build strength and lose weight', startDate: new Date('2024-01-15'), progress: 75, nextSession: new Date() },
  { id: '2', name: 'Mike Chen', email: 'mike@email.com', goals: 'Marathon preparation', startDate: new Date('2024-02-01'), progress: 60, nextSession: new Date() },
  { id: '3', name: 'Emma Davis', email: 'emma@email.com', goals: 'Improve flexibility and core strength', startDate: new Date('2024-03-10'), progress: 45 },
  { id: '4', name: 'Tom Wilson', email: 'tom@email.com', goals: 'General fitness and muscle gain', startDate: new Date('2024-01-20'), progress: 85, nextSession: new Date() },
  { id: '5', name: 'Lisa Brown', email: 'lisa@email.com', goals: 'Post-injury rehabilitation', startDate: new Date('2024-04-05'), progress: 30 },
  { id: '6', name: 'James Miller', email: 'james@email.com', goals: 'Athletic performance', startDate: new Date('2024-02-15'), progress: 90, nextSession: new Date() },
];

const Trainees: React.FC = () => {
  const [trainees, setTrainees] = useState<Trainee[]>(mockTrainees);
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newTrainee, setNewTrainee] = useState({
    name: '',
    email: '',
    goals: '',
  });

  const filteredTrainees = trainees.filter(t =>
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddTrainee = () => {
    if (!newTrainee.name || !newTrainee.email) {
      toast.error('Please fill in all required fields');
      return;
    }

    const trainee: Trainee = {
      id: Date.now().toString(),
      ...newTrainee,
      startDate: new Date(),
      progress: 0,
    };

    setTrainees([...trainees, trainee]);
    setIsDialogOpen(false);
    setNewTrainee({ name: '', email: '', goals: '' });
    toast.success('Trainee added successfully!');
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'bg-primary';
    if (progress >= 50) return 'bg-accent';
    return 'bg-muted-foreground';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-5xl mb-2">TRAINEES</h1>
          <p className="text-muted-foreground">Manage your clients and track their progress</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="gradient" size="lg">
              <Plus className="w-5 h-5" />
              Add Trainee
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle className="font-display text-2xl">NEW TRAINEE</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input
                  placeholder="Enter trainee's name"
                  value={newTrainee.name}
                  onChange={(e) => setNewTrainee({ ...newTrainee, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input
                  type="email"
                  placeholder="trainee@email.com"
                  value={newTrainee.email}
                  onChange={(e) => setNewTrainee({ ...newTrainee, email: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Goals</Label>
                <Textarea
                  placeholder="What are their fitness goals?"
                  value={newTrainee.goals}
                  onChange={(e) => setNewTrainee({ ...newTrainee, goals: e.target.value })}
                />
              </div>
              <Button onClick={handleAddTrainee} variant="gradient" className="w-full">
                Add Trainee
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          placeholder="Search trainees..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-11"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-card p-6">
          <p className="text-muted-foreground text-sm">Total Trainees</p>
          <p className="font-display text-4xl">{trainees.length}</p>
        </div>
        <div className="glass-card p-6">
          <p className="text-muted-foreground text-sm">Sessions This Week</p>
          <p className="font-display text-4xl">32</p>
        </div>
        <div className="glass-card p-6">
          <p className="text-muted-foreground text-sm">Avg. Progress</p>
          <p className="font-display text-4xl">
            {Math.round(trainees.reduce((acc, t) => acc + t.progress, 0) / trainees.length)}%
          </p>
        </div>
      </div>

      {/* Trainees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTrainees.map((trainee, index) => (
          <div 
            key={trainee.id} 
            className="glass-card p-6 animate-slide-up hover:border-primary/50 transition-all"
            style={{ animationDelay: `${index * 50}ms` }}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold text-lg">
                  {trainee.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium">{trainee.name}</p>
                  <p className="text-sm text-muted-foreground">{trainee.email}</p>
                </div>
              </div>
              <button className="p-2 hover:bg-secondary rounded-lg transition-colors">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>

            <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{trainee.goals}</p>

            <div className="mb-4">
              <div className="flex items-center justify-between text-sm mb-2">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{trainee.progress}%</span>
              </div>
              <Progress value={trainee.progress} className={getProgressColor(trainee.progress)} />
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <Calendar className="w-4 h-4" />
              <span>Started {trainee.startDate.toLocaleDateString()}</span>
            </div>

            <div className="flex gap-2">
              <Button variant="secondary" size="sm" className="flex-1">
                <MessageSquare className="w-4 h-4" />
                Message
              </Button>
              <Button variant="outline" size="sm" className="flex-1">
                <TrendingUp className="w-4 h-4" />
                Progress
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Trainees;
