export interface User {
  id: string;
  email: string;
  name: string;
  role: 'trainer' | 'trainee';
  avatar?: string;
}

export interface Exercise {
  id: string;
  name: string;
  category: string;
  muscleGroup: string;
  description: string;
  instructions: string[];
  sets?: number;
  reps?: string;
  duration?: string;
  videoUrl?: string;
  imageUrl?: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}

export interface ScheduleEvent {
  id: string;
  title: string;
  traineeId: string;
  traineeName: string;
  date: Date;
  startTime: string;
  endTime: string;
  type: 'training' | 'consultation' | 'assessment';
  notes?: string;
  exercises?: Exercise[];
}

export interface Message {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  content: string;
  timestamp: Date;
  read: boolean;
}

export interface Trainee {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  goals: string;
  startDate: Date;
  progress: number;
  nextSession?: Date;
}
